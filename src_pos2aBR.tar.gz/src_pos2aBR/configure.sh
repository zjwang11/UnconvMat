#!/bin/bash

echo >> ~/.bashrc
echo "export POS2ABRDATA="`pwd` >> ~/.bashrc
echo >> ~/.bashrc
